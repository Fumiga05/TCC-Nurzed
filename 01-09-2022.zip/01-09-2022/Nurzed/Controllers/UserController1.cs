﻿using Microsoft.AspNetCore.Mvc;
using Nurzed.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nurzed.Controllers
{
    public class UserController1 : Controller
    {
        public IActionResult Index()
        {
            
            Address addres = new Address(1, "");
            Contact contact = new Contact(1, "");
            Contract contract = new Contract("", "", "", "", "");
            Documents documents = new Documents("", "", "", "");
            University_Graduate university_graduate = new University_Graduate("","","","","","");
            Users users = new Users("","","","","","","","","","","");

            
            return View();
        }

        public IActionResult CadastrarADM()
        {
          

            return View();
        }

    }
}
