﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nurzed
{
    public class Users
    {
        private string id, name, password, status, mother_name, father_name, birth_date, birth_state, sex, created_at, updated_at;
        static MySqlConnection con = new MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno password=Senai1234");


        public Users(string id, string name, string password, string status, string mother_name, string father_name, string birth_date, string birth_state, string sex, string created_at, string updated_at)
        {
            this.id = id;
            this.name = name;
            this.password = password;
            this.status = status;
            this.mother_name = mother_name;
            this.father_name = father_name;
            this.birth_date = birth_date;
            this.birth_state = birth_state;
            this.sex = sex;
            this.created_at = created_at;
            this.updated_at = updated_at;
        }

        public string Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Password { get => password; set => password = value; }
        public string Status { get => status; set => status = value; }
        public string Mother_name { get => mother_name; set => mother_name = value; }
        public string Father_name { get => father_name; set => father_name = value; }
        public string Birth_date { get => birth_date; set => birth_date = value; }
        public string Birth_state { get => birth_state; set => birth_state = value; }
        public string Sex { get => sex; set => sex = value; }
        public string Created_at { get => created_at; set => created_at = value; }
        public string Updated_at { get => updated_at; set => updated_at = value; }

        public string RegisterUsers()
        {
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("INSERT INTO Users VALUES(@id,@name,@password,@status,@mother_name,@father_name,@birth_date,@sex,@created_at,@update_at)", con);
                qry.Parameters.AddWithValue("@id", id);
                qry.Parameters.AddWithValue("@name", name);
                qry.Parameters.AddWithValue("@password", password);
                qry.Parameters.AddWithValue("@status", status);
                qry.Parameters.AddWithValue("@mother_name", mother_name);
                qry.Parameters.AddWithValue("@father_name", father_name);
                qry.Parameters.AddWithValue("@birth_date", birth_date);
                qry.Parameters.AddWithValue("@sex", sex);
                qry.Parameters.AddWithValue("@created_at", created_at);
                qry.Parameters.AddWithValue("@update_at", updated_at);

                qry.ExecuteNonQuery();

                return "Usuário Cadastrado com Sucesso";
            }
            catch (Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Clone();
            }

        }

        public string EditUsers()
        {
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("UPDATE Users SET name = @name, password = @password,status = @status, mother_name = @mother_name, " +
                    "father_name = @father_name, birth_date = @birth_date, sex = @sex,");

                qry.Parameters.AddWithValue("@id", id);
                qry.Parameters.AddWithValue("@name", name);
                qry.Parameters.AddWithValue("@password", password);
                qry.Parameters.AddWithValue("@status", status);
                qry.Parameters.AddWithValue("@mother_name", mother_name);
                qry.Parameters.AddWithValue("@father_name", father_name);
                qry.Parameters.AddWithValue("@birth_date", birth_date);
                qry.Parameters.AddWithValue("@sex", sex);
                qry.Parameters.AddWithValue("@created_at", created_at);
                qry.Parameters.AddWithValue("@update_at", updated_at);

                qry.ExecuteNonQuery();

                return "Usuário editado com sucesso";


            }
            catch (Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }
        }

        public string AtivarInativar(string acao)
        {
            {
                string statusNovo, msg;
                try
                {
                    con.Open();
                    if (acao == "ativar")
                    {
                        statusNovo = "ativado";
                        msg = "Ativado";
                    }
                    else
                    {
                        statusNovo = "desativado";
                        msg = "Desativado";
                    }
                    MySqlCommand qry = new MySqlCommand("UPDATE Users status = @status WHERE id_user = @id_user", con);
                    qry.Parameters.AddWithValue("@id", id);
                    qry.Parameters.AddWithValue("@status", statusNovo);

                    qry.ExecuteNonQuery();

                    return msg + "com sucesso";
                }
                catch (Exception e)
                {
                    return "Erro: " + e.Message;
                }
                finally
                {
                    con.Close();
                }
            }

        }
    }
}





