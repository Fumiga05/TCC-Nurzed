﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Nurzed.Models
{
    public class Contact
    {
        private int id_user;
        private string cell;

        static MySqlConnection con = new MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno;password=Senai1234");

        public Contact(int id_user, string cell)
        {
            this.id_user = id_user;
            this.cell = cell;
        }

        public int Id_user { get => id_user; set => id_user = value; }
        public string Cell { get => cell; set => cell = value; }
        

        public string RegisterContact()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("INSERT INTO Contact(id_user,cell) VALUES (@id_user,@cell)", con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@cell", cell);


                return "";
            }
            catch(Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }
        }

        public string EditContact()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("UPDATE Contact SET cell = @cell WHERE id_user = @id_user");
                qry.Parameters.AddWithValue("@cell", cell);
                qry.Parameters.AddWithValue("id_user", id_user);
                qry.ExecuteNonQuery();

                return "";
            }catch(Exception e)
            {
                return "Erro " + e;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
