﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nurzed.Models
{
    public class Address
    {
        private int id_user;
        private string cep;
        static MySqlConnection con = new  MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno;password=Senai1234");

        public Address(int id_user, string cep)
        {
            this.id_user = id_user;
            this.cep = cep;
        }

   
        public int Id_user { get => id_user; set => id_user = value; }
        public string Cep { get => cep; set => cep = value; }

        public string RegisterAddress()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("INSERT INTO Address(id_user,cep) VALUES (@id_user, @cep)",con);

                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@cep", cep);
                qry.ExecuteNonQuery();

                return "";
                
                    }
            catch(Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }
        }
        public string EditAddress()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("UPDATE Address SET cep = @cep WHERE id_user = @id_user",con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@cep", cep);
                qry.ExecuteNonQuery();

                return "";
                    
            }catch(Exception e)
            {
                return "Erro " + e;
            }
            finally
            {
                con.Close();
            }
        }
    }
    
  
}
