﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Nurzed
{
    public class Documents
    {
        private string id,id_user,cpf,rg;
        static MySqlConnection con = new MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno;password=Senai1234");

        public Documents(string id, string id_user, string type, string number)
        {
            this.id = id;
            this.id_user = id_user;
            this.cpf = type;
            this.rg = number;
        }

        public string Id { get => id; set => id = value; }
        public string Id_user { get => id_user; set => id_user = value; }
        public string Type { get => cpf; set => cpf = value; }
        public string Number { get => rg; set => rg = value; }


        public string RegisterDocuments()
        {
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("INSERT INTO Documents VALUES(@id_user,@cpf,@rg)", con);
                qry.Parameters.AddWithValue("@id_user",id_user);
                qry.Parameters.AddWithValue("@cpf", cpf);
                qry.Parameters.AddWithValue("rg", rg);

                return "";
                
                }catch(Exception e) { 
                return "" +
                "Erro: " + e;

            }
            finally { 
                con.Close();
            }
    }
        public string EditDocuments()
        {
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("UPDATE Documents SET cpf = @cpf, rg = @rg WHERE id_user = @id_user ",con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@cpf", cpf);
                qry.Parameters.AddWithValue("rg", rg);

                return "";

            }catch(Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }

        }
    }


   
    
}
