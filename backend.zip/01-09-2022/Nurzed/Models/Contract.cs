﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nurzed.Models
{
    public class Contract
    {

        private string id_user, register, specialty, role, type;
        static MySqlConnection con = new MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno;password=Senai1234");

        public Contract(string id_user, string register, string specialty, string role, string type)
        {
            this.id_user = id_user;
            this.register = register;
            this.specialty = specialty;
            this.role = role;
            this.type = type;
        }

        public string Id_user { get => id_user; set => id_user = value; }
        public string Register { get => register; set => register = value; }
        public string Specialty { get => specialty; set => specialty = value; }
        public string Role { get => role; set => role = value; }
        public string Type { get => type; set => type = value; }
    
        public string RegisterContract()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("INSERT INTO Contract VALUES(@id_user,@register,@specialty,@role,@type)", con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@register", register);
                qry.Parameters.AddWithValue("@specialty", specialty);
                qry.Parameters.AddWithValue("@role", role);
                qry.Parameters.AddWithValue("@type", type);

                return "";
            }catch(Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }
        }

        public string EditContract()
        {
            try
            {
                con.Open();

                MySqlCommand qry = new MySqlCommand("UPDATE Contract SET register = @register, specialty = @specialty, role = @role, type = @type WHERE id_user = @id_user",con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@register", register);
                qry.Parameters.AddWithValue("@specialty", specialty);
                qry.Parameters.AddWithValue("@role", role);
                qry.Parameters.AddWithValue("@type", type);

                return "";
            }catch(Exception e)
            {
                return "Erro: " + e;
            }
            finally
            {
                con.Close();
            }
        }

    }
}
