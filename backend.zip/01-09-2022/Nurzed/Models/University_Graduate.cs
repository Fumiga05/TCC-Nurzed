﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nurzed.Models
{
    public class University_Graduate
    {
        private string id_user, start_date_university, end_date_university, coren, university_name, course;
        static MySqlConnection con = new MySqlConnection("server=ESN509VMYSQL;database=victor;user id=aluno;password=Senai1234");

        public University_Graduate(string id_user, string start_date_university, string end_date_university, string coren, string university_name, string course)
        {
            this.id_user = id_user;
            this.start_date_university = start_date_university;
            this.end_date_university = end_date_university;
            this.coren = coren;
            this.university_name = university_name;
            this.course = course;
        }

        public string Id_user { get => id_user; set => id_user = value; }
        public string Start_date_university { get => start_date_university; set => start_date_university = value; }
        public string End_date_university { get => end_date_university; set => end_date_university = value; }
        public string Coren { get => coren; set => coren = value; }
        public string University_name { get => university_name; set => university_name = value; }
        public string Course { get => course; set => course = value; }

        public string RegisterUniversity_Graduate()
        {

            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("INSERT INTO University_Graduate VALUES(@id_user,start_date_university,end_date_university,coren,university_name,course)", con);
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@start_date_university", start_date_university);
                qry.Parameters.AddWithValue("@end_date_university", end_date_university);
                qry.Parameters.AddWithValue("@coren", coren);
                qry.Parameters.AddWithValue("@university_name", university_name);
                qry.Parameters.AddWithValue("@course", course);

                qry.ExecuteNonQuery();
                return "";
            }
            catch (Exception e)
            {
                return "Erro " + e;
            }
            finally
            {
                con.Close();
            }
        }

        public string EditUniversity_Graduate()
        {
            try
            {
                con.Open();
                MySqlCommand qry = new MySqlCommand("UPDATE University_Graduate SET start_date_university = @start_date_university, end_date_university = @end_date_university," +
                    "coren = @coren, university_name = @university_name, course = @course");
                qry.Parameters.AddWithValue("@id_user", id_user);
                qry.Parameters.AddWithValue("@start_date_university", start_date_university);
                qry.Parameters.AddWithValue("@end_date_university", end_date_university);
                qry.Parameters.AddWithValue("@coren", coren);
                qry.Parameters.AddWithValue("@university_name", university_name);
                qry.Parameters.AddWithValue("@course", course);

                qry.ExecuteNonQuery();
                return "";

            }catch (Exception e)
            {
                return "Erro " + e;
            }
            finally
            {
                con.Close();
            }
        }



    }
}
   

